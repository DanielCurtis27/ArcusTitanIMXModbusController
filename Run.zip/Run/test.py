import Probe as Pr
import time

probe1 = Pr.Probes(1, '169.254.246.101', 1000, 34376.0743)

Pr.ConnectandInitializeProbe(probe1)
time.sleep(1)

Pr.Home()
print("homed")

Pr.Move(probe1, 20)
time.sleep(3)

Pr.Disconnect()